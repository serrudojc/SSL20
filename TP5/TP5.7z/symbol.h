void agregar(char *variable);
int existe(char *variable);
