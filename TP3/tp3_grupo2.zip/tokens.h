enum token{
	FDT,			//0
	ASIGNACION,		//1
	PROGRAMA,		//2
	FIN,			//3
	DECLARAR,		//4
	LEER,			//5
	ESCRIBIR,		//6	
	IDENTIFICADOR,	//7
	CONSTANTE,		//8
};